package com.keagk.ace

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.*
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

data class Q(val q:String,val opts:List<String>,val ans:Int,val exp:String)

class MainActivity : AppCompatActivity() {
    private lateinit var question: TextView
    private lateinit var options: LinearLayout
    private lateinit var next: Button
    private lateinit var scoreView: TextView
    private var index=0
    private var score=0
    private var rewardedAd: RewardedAd?=null

    private val qs = listOf(
        Q("Which city is known as the Silicon Valley of India?", ["Mysuru", "Bengaluru", "Hubballi", "Mangaluru"], 1, "Bengaluru is widely known for India's technology industry."),
        Q("The Hampi monuments are associated with which empire?", ["Maurya", "Vijayanagara", "Mughal", "Gupta"], 1, "Hampi was a major center of the Vijayanagara Empire."),
        Q("Jog Falls is formed by which river?", ["Kaveri", "Krishna", "Sharavathi", "Tungabhadra"], 2, "Jog Falls is on the Sharavathi River."),
        Q("Which is the highest peak in Karnataka?", ["Mullayanagiri", "Kudremukh", "Tadiandamol", "Brahmagiri"], 0, "Mullayanagiri is Karnataka's highest peak."),
        Q("Fundamental Rights are contained in which Part of the Constitution?", ["Part I", "Part II", "Part III", "Part IV"], 2, "Fundamental Rights are in Part III."),
        Q("The Quit India Movement was launched in:", ["1930", "1942", "1947", "1919"], 1, "The Quit India Movement was launched in 1942."),
        Q("Who founded the Mauryan Empire?", ["Ashoka", "Chandragupta Maurya", "Bindusara", "Harsha"], 1, "Chandragupta Maurya founded the Mauryan Empire."),
        Q("Which soil is generally suitable for cotton cultivation?", ["Black", "Laterite", "Alluvial", "Desert"], 0, "Black soil has strong moisture-retention properties."),
        Q("Which vitamin is produced in the skin in sunlight?", ["A", "B12", "C", "D"], 3, "Sunlight enables vitamin D synthesis."),
        Q("The SI unit of electric current is:", ["Volt", "Watt", "Ampere", "Ohm"], 2, "Electric current is measured in amperes."),
        Q("The capital of Karnataka is:", ["Mysuru", "Bengaluru", "Belagavi", "Shivamogga"], 1, "Bengaluru is the capital of Karnataka."),
        Q("Vidhana Soudha is located in:", ["Bengaluru", "Mysuru", "Dharwad", "Kalaburagi"], 0, "Vidhana Soudha is the seat of the Karnataka legislature in Bengaluru."),
        Q("Which river is often called the lifeline of Karnataka's southern region?", ["Kaveri", "Narmada", "Yamuna", "Mahanadi"], 0, "The Kaveri is an important river for southern Karnataka."),
        Q("Badami was historically associated with which dynasty?", ["Chalukyas", "Cholas", "Pallavas", "Satavahanas"], 0, "Badami was the capital of the Early Chalukyas."),
        Q("Gol Gumbaz is located at:", ["Vijayapura", "Hassan", "Udupi", "Tumakuru"], 0, "Gol Gumbaz is a famous monument in Vijayapura."),
        Q("Which Article deals with equality before law?", ["Article 14", "Article 19", "Article 21", "Article 32"], 0, "Article 14 guarantees equality before law and equal protection of laws."),
        Q("The President of India is elected by:", ["Direct popular vote", "An electoral college", "Lok Sabha alone", "Rajya Sabha alone"], 1, "The President is elected by an electoral college of elected representatives."),
        Q("The Rajya Sabha is also called:", ["House of the People", "Council of States", "Federal Assembly", "People's Council"], 1, "Rajya Sabha is the Council of States."),
        Q("Who is the constitutional head of a state?", ["Chief Minister", "Governor", "Speaker", "Chief Secretary"], 1, "The Governor is the constitutional head of a state."),
        Q("The Indian Constitution was adopted on:", ["15 August 1947", "26 November 1949", "26 January 1950", "2 October 1950"], 1, "The Constitution was adopted on 26 November 1949."),
        Q("Who is known as the Father of the Indian Constitution?", ["Jawaharlal Nehru", "B. R. Ambedkar", "Sardar Patel", "Rajendra Prasad"], 1, "B. R. Ambedkar chaired the Drafting Committee."),
        Q("The Green Revolution is mainly associated with increased production of:", ["Food grains", "Tea", "Coffee", "Rubber"], 0, "The Green Revolution greatly increased food-grain production."),
        Q("Photosynthesis mainly occurs in the:", ["Nucleus", "Chloroplast", "Mitochondria", "Ribosome"], 1, "Chloroplasts contain chlorophyll and are the main site of photosynthesis."),
        Q("The chemical symbol for sodium is:", ["So", "Sd", "Na", "S"], 2, "Na is the chemical symbol for sodium."),
        Q("The largest planet in the Solar System is:", ["Earth", "Saturn", "Jupiter", "Neptune"], 2, "Jupiter is the largest planet."),
        Q("The Red Planet is:", ["Venus", "Mars", "Mercury", "Uranus"], 1, "Mars is commonly called the Red Planet."),
        Q("The headquarters of ISRO is in:", ["Bengaluru", "Hyderabad", "Chennai", "New Delhi"], 0, "ISRO headquarters is in Bengaluru."),
        Q("The force that pulls objects toward Earth is:", ["Friction", "Gravity", "Magnetism", "Pressure"], 1, "Gravity attracts objects toward Earth."),
        Q("Water boils at sea level at approximately:", ["50\u00b0C", "75\u00b0C", "100\u00b0C", "125\u00b0C"], 2, "Water boils at about 100\u00b0C at standard atmospheric pressure."),
        Q("Which gas is most abundant in Earth's atmosphere?", ["Oxygen", "Nitrogen", "Carbon dioxide", "Hydrogen"], 1, "Nitrogen makes up about 78% of Earth's atmosphere."),
        Q("The Western Ghats are also known as:", ["Sahyadri", "Aravalli", "Shivalik", "Vindhya"], 0, "The Western Ghats are also called the Sahyadri range in parts of India."),
        Q("The longest river in India is commonly considered:", ["Ganga", "Godavari", "Narmada", "Krishna"], 0, "The Ganga is generally regarded as India's longest river."),
        Q("The Tropic of Cancer passes through how many Indian states?", ["6", "7", "8", "9"], 2, "The Tropic of Cancer passes through 8 Indian states."),
        Q("The largest state in India by area is:", ["Madhya Pradesh", "Rajasthan", "Maharashtra", "Uttar Pradesh"], 1, "Rajasthan is India's largest state by area."),
        Q("The smallest state in India by area is:", ["Goa", "Sikkim", "Tripura", "Manipur"], 0, "Goa is the smallest state by area."),
        Q("The Battle of Plassey was fought in:", ["1757", "1764", "1857", "1942"], 0, "The Battle of Plassey took place in 1757."),
        Q("The Revolt of 1857 began at:", ["Meerut", "Delhi", "Kanpur", "Lucknow"], 0, "The revolt began at Meerut in May 1857."),
        Q("Who was the first President of independent India?", ["Rajendra Prasad", "S. Radhakrishnan", "Zakir Husain", "V. V. Giri"], 0, "Dr. Rajendra Prasad was India's first President."),
        Q("The Dandi March was associated with:", ["Salt Satyagraha", "Quit India", "Swadeshi Movement", "Home Rule"], 0, "Gandhi's Dandi March launched the Salt Satyagraha."),
        Q("The study of earthquakes is called:", ["Ecology", "Seismology", "Geology", "Meteorology"], 1, "Seismology is the scientific study of earthquakes."),
        Q("The SI unit of force is:", ["Joule", "Newton", "Pascal", "Watt"], 1, "Force is measured in newtons."),
        Q("The currency of Japan is:", ["Won", "Yuan", "Yen", "Ringgit"], 2, "Japan uses the yen."),
        Q("The headquarters of the United Nations is in:", ["Geneva", "Paris", "New York", "London"], 2, "The UN headquarters is in New York City."),
        Q("Which is a renewable source of energy?", ["Coal", "Petroleum", "Solar energy", "Natural gas"], 2, "Solar energy is renewable."),
        Q("The Panchayati Raj system relates to:", ["Local self-government", "Judiciary", "Banking", "Foreign affairs"], 0, "Panchayati Raj is India's system of rural local self-government."),
        Q("The minimum voting age in India is:", ["16", "18", "21", "25"], 1, "Indian citizens can vote from age 18, subject to registration requirements."),
        Q("Which house of Parliament is permanent?", ["Lok Sabha", "Rajya Sabha", "Both", "Neither"], 1, "Rajya Sabha is a permanent house and is not subject to dissolution."),
        Q("The national animal of India is:", ["Lion", "Elephant", "Tiger", "Leopard"], 2, "The Bengal tiger is India's national animal."),
        Q("The national aquatic animal of India is:", ["Ganges river dolphin", "Blue whale", "Crocodile", "Olive ridley turtle"], 0, "The Ganges river dolphin is India's national aquatic animal."),
        Q("Which Karnataka city is famous for Mysore Palace?", ["Mysuru", "Ballari", "Bidar", "Raichur"], 0, "Mysuru is famous for the Mysore Palace."),
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        question=findViewById(R.id.question)
        options=findViewById(R.id.options)
        next=findViewById(R.id.next)
        scoreView=findViewById(R.id.score)
        MobileAds.initialize(this)
        loadRewarded()
        showQuestion()
    }

    private fun loadRewarded() {
        RewardedAd.load(this, "ca-app-pub-3940256099942544/5224354917",
            AdRequest.Builder().build(), object: RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) { rewardedAd=ad }
            })
    }

    private fun showQuestion() {
        question.text="Question ${index+1}/${qs.size}\n\n${qs[index].q}"
        options.removeAllViews()
        qs[index].opts.forEachIndexed { n,text ->
            val b=Button(this); b.text="${'A'+n}. $text"
            b.setOnClickListener { choose(n) }
            options.addView(b)
        }
        next.isEnabled=false
        next.setOnClickListener { index++; if(index<qs.size) showQuestion() else finishQuiz() }
    }

    private fun choose(n:Int) {
        val q=qs[index]
        if(n==q.ans) score++
        Toast.makeText(this, if(n==q.ans) "Correct! ${q.exp}" else "Incorrect. ${q.exp}", Toast.LENGTH_LONG).show()
        next.isEnabled=true
        for(i in 0 until options.childCount) options.getChildAt(i).isEnabled=false
    }

    private fun finishQuiz() {
        question.text="Test Complete!\n50-question practice bank"
        options.removeAllViews()
        scoreView.text="Score: $score / ${qs.size}"
        next.text="Watch ad for bonus quiz"
        next.isEnabled=true
        next.setOnClickListener {
            rewardedAd?.show(this) {
                Toast.makeText(this, "Bonus unlocked! Start another quiz.", Toast.LENGTH_SHORT).show()
                index=0; score=0; next.text="Next Question"; showQuestion(); loadRewarded()
            } ?: run {
                Toast.makeText(this, "Ad isn't ready yet. Try again.", Toast.LENGTH_SHORT).show()
                loadRewarded()
            }
        }
    }
}