# KEA Ace GK Pro — APK-ready Android project

This is the larger Android version of the KEA Ace GK quiz app.

## Included
- 50 original KEA-style practice questions
- Karnataka GK, Indian Polity, History, Geography, Science and General GK
- Instant answer feedback and explanations
- Rewarded-ad test integration using Google's official test ad unit
- Android Studio / Gradle project

## Important
This folder is **APK-ready source**, not a precompiled APK. The current environment does not have the Android SDK/Gradle toolchain required to compile an APK.

Open the project in Android Studio, sync Gradle, then use **Build > Build APK(s)** for a debug APK. For a release APK, create/sign a release key. Android's official documentation explains that release APKs must be signed, while debug APKs are signed automatically for development.

Before publishing, replace the Google test AdMob IDs with your own production IDs and complete your store/developer setup.

Questions are original practice questions written in a KEA-style format; they are not reproduced official KEA questions.
